


public class Alg{

//public static Determination(){}


}