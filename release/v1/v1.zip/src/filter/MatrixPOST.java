package filter;


import java.util.StringTokenizer;
import matrix.*;


public class MatrixPOST{

public static Matrix parse(String str){

int m=0;
int n=0;
int i=0;
String []resultStr = null;
StringTokenizer stroki = new StringTokenizer(str, "\r\n");
StringTokenizer el;
m = stroki.countTokens();
while(stroki.hasMoreTokens()){
	el = new StringTokenizer(stroki.nextToken());
	n = el.countTokens();
	if (resultStr==null) resultStr = new String[m*n];
	while(el.hasMoreTokens()) resultStr[i++] = el.nextToken();
	}
return (new Matrix(m,n,resultStr));
}

}