package filter;

import junit.framework.*;
import matrix.*;

public class TestMatrixPOST extends TestCase{

public void testPOST(){
Matrix A = MatrixPOST.parse("4 3\r\n2 1");
assertEquals(A!=null, true);
}

}
